function [ S ] = optimization( Si,c ,gamma)
%OPTIMIZATION �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[n,~,m]=size(Si);
maxiter=10;
alpha=ones(1,m)./m;
for j=1:m
    dd=1./max(sum(Si(:,:,j),2),eps);
    Si(:,:,j)=bsxfun(@times,Si(:,:,j),dd);
end
S=sum(Si,3)./m;
S = (S+S')/2;
D = diag(sum(S));
L = D -S;
B=S;
[F, ~, evs]=eig1(L, c, 0);
d1=zeros(n,m);
for k=1:m
    tmp1=Si(:,:,k).*log(max(Si(:,:,k)./max(B,eps),eps));
    d1(:,k)=sum(tmp1,2);
end
rho=1;
for ii=1:maxiter
    d2=zeros(n,1);
    for j=1:m
        d2=d2+d1(:,k)./alpha(k);
    end
    if ii==1
        sort_d2=sort(d2);
        lambda=2.*sort_d2(min(floor(n/maxiter)*ii,n));
    else
        lambda=lambda*1.1;
    end
    w=min(lambda./max(2.*d2,eps),1);
    
    distf = L2_distance_1(F',F');
    distf=distf-diag(diag(distf));
    C=zeros(n,n);
    for k=1:m
        C=C+Si(:,:,k)./alpha(k);
    end
    C=bsxfun(@times,C,w.^2);
   
    B=optimize_S(distf,C,rho);
   
    for j=1:n
        v=B(j,:)-rho./(2*gamma).*distf(j,:);

        S(j,:)=EuclideanPro(ones(1,n),v);
    end

    d1=zeros(n,m);
    for k=1:m
        tmp1=Si(:,:,k).*log(max(Si(:,:,k)./max(B,eps),eps));
        d1(:,k)=sum(tmp1,2);
    end

    S = (S+S')/2;
    D = diag(sum(S));
    L = D-S;
    F_old = F;
    [F, ~, ev]=eig1(L, c, 0);
    evs(:,ii+1) = ev;
    
    tmp2=bsxfun(@times,d1,w.^2);
    d3=sum(tmp2);
    d3=sqrt(d3);
    alpha=d3./sum(d3);
    
    fn1 = sum(ev(1:c));
    fn2 = sum(ev(1:c+1));
    if fn1 > 0.000000001
        rho = 2*rho;
    elseif fn2 < 0.00000000001
        rho = rho/2;  F = F_old;
    elseif ii>1
        break;
    end
    
    

end



