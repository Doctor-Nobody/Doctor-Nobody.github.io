clear
rand('state',0);

name='Lung_203n_3312d_5c_uni.mat';
   
load(name);
c=length(unique(y));
m=20;
n=length(y);
result_acc=zeros(1,10);
result_nmi=result_acc;
for iter=1:10
    Ai=zeros(n,n,m);
    for j=1:m
        idxi=(iter-1)*20+j;
        YY=sparse(Yi{idxi});
        Ai(:,:,j)=full(YY*YY');

    end
    for gam=-5:5
        gamma=10.^gam
        
        S  =optimization( Ai,c,gamma);
        
        [clusternum, ypred]=graphconncomp(sparse(S)); 
        ypred = ypred';
        res=ClusteringMeasure(y,ypred)
        result_acc(iter,gam+6)=res(1);
        result_nmi(iter,gam+6)=res(2);
            
        save(['./result/' name '.mat'],'result_acc','result_nmi');
        
    end

    
end