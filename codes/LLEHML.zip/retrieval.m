function result = retrieval( query,data )
%retrieve the test set

A=query'*data;
B=data'*data;
C=query'*query;
d=diag(B);
distance=bsxfun(@plus, -2*A,diag(C));
distance=bsxfun(@plus,distance,diag(B)');


[row,col]=size(distance);
result=zeros(row,col);
for i=1:row
    [~,result(i,:)]=sort(distance(i,:),'ascend');
end

end

