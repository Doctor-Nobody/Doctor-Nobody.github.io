function [ Z_T,Z_I ] = LLEHML( T_tr,T_te,I_tr,I_te,W,d,k,beta,gamma1,gamma2,normalize )
%T_tr: text train set. n1*d1 matrix, n1: number of texts in train set, d1: dimension
%T_te: text test set. n2*d1 matrix, n2: number of texts in test set, d1: dimension 
%I_tr: image train set. n3*d2 matrix, n3: number of images in train set, d2: dimension
%I_te: image test set. n4*d2 matrix, n4: number of images in test set, d2: dimension 
%W: heterogeneous constraint matrix, n1*n3 matrix, W_{ij}=1: must-link;
%W_{ij}=-1: cannot-link; W_{ij}=0: otherwise
%d: dimension of new represent
%k: k-NN parameter
%beta,gamma1,gamma2: balancing parameter
%normalize: if normalize=1, normalize; otherwise, does not normalize
%Z_T: new representation of texts in test set. d*n2 matrix
%Z_T: new representation of images in test set. d*n4 matrix


X=T_tr';
Y=I_tr';
[row1,~]=size(T_tr);
[row2,~]=size(I_tr);
[~,col1]=size(T_tr);
[~,col2]=size(I_tr);
clear('I_tr','T_tr');


if normalize==1
    for i=1:col1
        X(i,:)=X(i,:)./max(1e-12,norm(X(i,:)));
    end

    for i=1:col2
        Y(i,:)=Y(i,:)./max(1e-12,norm(Y(i,:)));
    end

    for i=1:col1
        T_te(:,i)=T_te(:,i)./max(1e-12,norm(T_te(:,i)));
    end

    for i=1:col2
        I_te(:,i)=I_te(:,i)./max(1e-12,norm(I_te(:,i)));
    end
end

Z=LLE(X,Y,W,k,d,beta);

Z1=Z(:,1:row1);
Z2=Z(:,row1+1:row1+row2);
clear('Z');

I1=eye(col1,col1);
W2=Z1*X'/(X*X'+gamma1*I1);
I2=eye(col2,col2);
W3=Z2*Y'/(Y*Y'+gamma2*I2);

Z_T=W2*T_te';
Z_I=W3*I_te';



end

