function KNNMatrix = KNNGraph( X,k )
%KNNGRAPH Summary of this function goes here
%   Detailed explanation goes here
B=squareform(pdist(X','euclidean'));
[~,row]=size(X);
KNNMatrix=zeros(row,row);
for i=1:row
    [~,index]=sort(B(i,:),'ascend');
    KNNMatrix(i,index(1:k+1))=1;
    KNNMatrix(i,i)=0;
end
clear('A','B');
end

