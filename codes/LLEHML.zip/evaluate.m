function MAP = evaluate(query,data,class_te)
%query: query matrix, d*n1 matrix
%data: d*n2 matrix
%class_te: ground truth of test set, n2*1 matrix
%MAP: mean average precision

sort_result=retrieval(query,data);
[n,~]=size(class_te);
AP=zeros(1,n);
for i=1:n
    a=class_te';
    b=sort_result(i,:);
    c=a(b);
    k=find(c==class_te(i));
    [~,col]=size(k);
    d=1:col;
    d=d./k;
    AP(i)=sum(d)/col;
end
MAP=sum(AP)/n;
end

