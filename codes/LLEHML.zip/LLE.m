function Z = LLE( X,Y,W,k,d,beta)
%X: texts matrix d1*n1 matrix
%Y: image matrix d2*n2 matrix
%k: k-NN parameter
%d: dimension of new represent
%beta: balancing parameter 
%Z: all data in new space d*(n1+n2) matrix
 
[d1,n1]=size(X);
[d2,n2]=size(Y);
KNNX=KNNGraph(X,k);
KNNY=KNNGraph(Y,k);

I=1e-3*eye(k);
W1=sparse(n1,n1);
W4=sparse(n2,n2);


for i=1:n1
    knnindex=find(KNNX(i,:)==1);
    knnindex=[i,knnindex];
    Xnew=X(:,knnindex);
    A=Xnew'*Xnew;
    Q=A(2:k+1,2:k+1);
    a=A(1,:);
    a(1)=[];
    Q=bsxfun(@minus,Q,a);
    Q=bsxfun(@minus,Q,a');
    Q=Q+A(1,1);
    w=(Q+trace(Q)*I)\ones(k,1);
    w=w./sum(w);
    knnindex(1)=[];
    W1(i,knnindex)=w';
end

for i=1:n2
    knnindex=find(KNNY(i,:)==1);
    knnindex=[i,knnindex];
    Ynew=Y(:,knnindex);
    A=Ynew'*Ynew;
    Q=A(2:k+1,2:k+1);
    a=A(1,:);
    a(1)=[];
    Q=bsxfun(@minus,Q,a);
    Q=bsxfun(@minus,Q,a');
    Q=Q+A(1,1);
    w=(Q+trace(Q)*I)\ones(k,1);
    w=w./sum(w);
    knnindex(1)=[];
    W4(i,knnindex)=w';
end
clear('KNNX','KNNY','I','A','Q','Xnew','Ynew','knnindex');

I1=sparse(eye(n1));
I4=sparse(eye(n2));

M1=(I1-W1)'*(I1-W1);
M1=(M1+M1')/2;
M4=(I4-W4)'*(I4-W4);
M4=(M4+M4)'/2;
clear('I1','I4','W1','W4');
N2=-W;
N3=N2';
sumW1=sum(W,2);
sumW2=sum(W,1);

N1=sparse(diag(sumW1));
N4=sparse(diag(sumW2));
clear('W','sumW1','sumW2');

N1=M1+beta*N1;
N2=beta*N2;
N3=beta*N3;
N4=M4+beta*N4;
clear('M1','M4');
clear('X','Y');
N=zeros(n1+n2,n1+n2);
N(1:n1,1:n1)=N1;
N(1:n1,n1+1:n1+n2)=N2;
N(n1+1:n1+n2,1:n1)=N3;
N(n1+1:n1+n2,n1+1:n1+n2)=N4;
clear('N1','N2','N3','N4');
N=sparse(N);
[Z,V]=eigs(N,d+1,'sa');
Z=Z(:,2:d+1);
Z=Z';


end


