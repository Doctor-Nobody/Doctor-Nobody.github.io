clear;
rand('state',0);
load('20NG_3970n_1000d_4c.mat');
c=length(unique(y));
nSmp=length(y);
M=10;
alpha=0.85;
k=20;
for i=1:10
    idx=(i-1)*M+1:i*M;
    YY=Yi(idx);
    for j=1:M
        Wi{j}=YY{j}*YY{j}';
    end
    
                
    pred=CEAM(YY,Wi,c,alpha,k);
                
    res=ClusteringMeasure(y,pred)
               
    acc_our(i)=res(1);
    nmi_our(i)=res(2);
end
[mean(acc_our) mean(nmi_our)]