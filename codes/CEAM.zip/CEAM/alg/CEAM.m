function pred = CEAM(Yi,Wi,c,alpha,k)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
m=length(Yi);
[n,~]=size(Yi{1});

options=[];
options.NeighborMode='KNN';
options.WeightMode='Cosine';
options.k=k;
options.bSelfConnected=1;

Di=zeros(n,m);
for i=1:m
    d=1./sqrt(max(sum(Wi{i},2)+m-1,eps));
    Di(:,i)=d;
    WW=bsxfun(@times,Wi{i},d);
    WW=bsxfun(@times,WW,d');
    Wi{i}=WW;
end

Ytmp=Yi;
maxiter=20;
maxiter1=5;

for j=1:m
    [~,ci]=size(Yi{j});
    for k=1:m
        Ytmp{j,k}=Yi{j};
    end
end

for iter=1:maxiter1
    for j=1:m
        for i=1:maxiter
            for k1=1:m
                YY=alpha.*Wi{k1}*Ytmp{j,k1}+(1-alpha).*Yi{j};
      
                for k2=1:m
                    if k2==k1
                        continue;
                    else
                        dd=alpha.*Di(:,k1).*Di(:,k2);
                        YY=YY+bsxfun(@times,Ytmp{j,k2},dd);
                    end
                end
                
                Ytmp2{1,k1}=YY;

            end
            Ytmp(j,:)=Ytmp2;
        end
        Wi{j}=constructW(Ytmp{j,j},options);
        d=1./sqrt(max(sum(Wi{j},2)+m-1,eps));
        WW=bsxfun(@times,Wi{j},d);
        WW=bsxfun(@times,WW,d');
        Wi{j}=WW;
        Di(:,j)=d;
    end
end


W=Wi{1};
for t=2:m
    W=W+Wi{t};
end
W=W./m;
d=1./sqrt(max(sum(W,2),eps));
L=eye(n)-diag(d)*W*diag(d);
L=(L+L')./2;
eigvec = eig1(L, c+1, 0);
eigvec(:,1)=[];
Y=discretisation(eigvec);
[~,pred]=max(Y,[],2);

