clear;
clc;

rand('state',0);

dataname = 'har';
load(['data\bc_pool_' dataname]);

nKmeans = 100;
nClustering = 10;
nRuns = floor(nKmeans/nClustering);
Y = cell(1,nClustering);
c = length(unique(y));
G = get_dummies(g);

lambda1 = 0.001;
lambda2 = 0;


t1 = 0;
t2 = 0;

for i=1:nRuns
    i
    for j=1:nClustering
        Y{j} = bac_Y{nClustering*(i-1) + j};
    end  
    [pre_Y] = fce(Y,G,lambda1,lambda2);    
    fair(i) = compute_fair(G'*pre_Y);
    mnce(i) = MNCE(G'*pre_Y);
    [ne(i),bal(i),~,~] = BalanceEvl(c,sum(G'*pre_Y,1));
    [~,pre_y] = max(pre_Y, [], 2);
    result = ClusteringMeasure(y,pre_y);
    acc(i) = result(1);
    nmi(i) = result(2);
end


acc = mean(acc);
nmi = mean(nmi);
fair = mean(fair);
mnce = mean(mnce);
bal = mean(bal);
ne = mean(ne);


save(['./result/' dataname], 'acc', 'nmi', 'fair', 'mnce', 'bal', 'ne');