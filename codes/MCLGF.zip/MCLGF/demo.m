clear;
load('3sources.mat');
optgraph=[];
optgraph.NeighborMode='KNN';
optgraph.k=10;
optgraph.WeightMode='HeatKernel';

rand('state',0)
m=length(X);
c=length(unique(Y));
n=length(Y);
S=zeros(n,n,m);
d=[];
for i=1:m
    X{i}=NormalizeFea(double(X{i}));
    XX=EuDist2(X{i},X{i});
    optsigma=median(XX(:));
    optgraph.t=optsigma;
    S(:,:,i)=constructW(X{i},optgraph);
    [~,d(i)]=size(X{i});
end
if n<mean(d)
    flag=1;
else
    flag=0;
end
acc_our=zeros(11,1);
nmi_our=zeros(11,1);
time_our=zeros(11,1);

r=2;

for i=1:11
    lambda=10^(i-6);
    [ label1,W ] = MVCGF( X,S,c,lambda,r,flag );
            
           
    res=ClusteringMeasure(Y,label1)
    acc_our(i)=res(1);
    nmi_our(i)=res(2);
end
