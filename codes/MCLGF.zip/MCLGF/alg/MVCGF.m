function [ label1,W,B ] = MVCGF( X,S,c,lambda,k,flag)
%OPTIMIZE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
m=length(X);
[n,~]=size(X{1});
alpha=ones(1,m)./m;
maxiter=20;
W=zeros(n,n);

if flag==1
    XX=zeros(n,n,m);
    for i=1:m
        XX(:,:,i)=X{i}*X{i}';
    end
end

for i=1:m
    W=W+S(:,:,i);
end
W=W./m;
dd=1./max(sum(W,2),eps);
W=bsxfun(@times,W,dd);

B=(eye(n)+W)./2;
Lambda1=zeros(n,n);
mu=1;
rho=1.05;
opt=[];
opt.Display='off';

for i=1:maxiter
    

    if flag==1
        B=LBFGSB2(B,XX,S,W,Lambda1,mu,k,m );
    else
        B=LBFGSB1(B,X,S,W,Lambda1,mu,k,m );
    end
    
    alpha_S=zeros(n,n);
    for v=1:m
        alpha_S=alpha_S+alpha(v).*alpha(v).*S(:,:,v);
    end

    W_tmp1=lambda.*alpha_S+Lambda1./4+mu./4.*(B-eye(n)./2);
    W_tmp2=sum(alpha.^2).*lambda+mu/8;
    W_tmp=W_tmp1./W_tmp2;
    W=optimize_W(W_tmp);



    for j=1:m
        r(j)=sum(sum((W-S(:,:,j)).^2));
    end
    alpha=(1./r)./sum(1./r);

     
    Lambda1=Lambda1+mu.*(B-(eye(n)+W)./2);

    mu=mu.*rho;
end

W=(W+W')./2;
d=1./sqrt(max(sum(W,2),eps));
dw=bsxfun(@times,W,d);
dwd=bsxfun(@times,dw,d');
L=eye(n)-dwd;
L=(L+L')./2;
eigvec = eig1(L, c+1, 0);
eigvec(:,1)=[];
Y=discretisation(eigvec);
[label1,~]=find(Y');


    


end

