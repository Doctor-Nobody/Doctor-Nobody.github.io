function [ obj,grad ] = obj_B2( XX,S,W,Lambda1,mu,k,n,m,x)
%OBJ_F2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%tic
B=reshape(x,n,n);
clear x;

Bk{1}=B;
for r=2:k
    Bk{r}=Bk{r-1}*B;
end




obj1=0;
for v=1:m

    BXX=Bk{k}*XX(:,:,v);
    BIS=(eye(n)-S(:,:,v))*Bk{k};
    BISX{v}=BIS*XX(:,:,v);
    obj1=obj1+sum(sum(BIS.*BXX));
end

obj2=sum(sum(Lambda1.*B));
BIW=B-(eye(n)+W)./2;
obj3=mu./2.*sum(sum(BIW.^2));

obj=obj1+obj2+obj3;

grad1=0;

if k==1
    for v=1:m
        
        grad1=grad1+2.*BISX{v};
    end
else
    
    for v=1:m
        grad1=grad1+2.*BISX{v}*Bk{k-1}';
        for r=1:k-2
            grad1=grad1+2.*Bk{r}'*BISX{v}*Bk{k-1-r}';
        end
        grad1=grad1+2.*Bk{k-1}'*BISX{v};
    end
end


grad3=mu.*BIW;

grad=grad1+Lambda1+grad3;

grad=reshape(grad,n*n,1);

    
    

end

