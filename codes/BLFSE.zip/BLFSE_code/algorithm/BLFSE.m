function [ idx,S ] = BLFSE( X,Vi,Si,c,gamma1,gamma2 )
%X: d*n
%Vi:m*d
%Si:n*n*m
%W:d*c
%v:d*1
%alpha:d*1
[d,n]=size(X);
[~,~,m]=size(Si);
S=sum(Si,3)./m;
D = diag(sum(S));
L = D - S;
[F, ~, evs]=eig1(L, c, 0);
sum_Vi=1./max(eps,sum(Vi,2));
Vi=bsxfun(@times,Vi,sum_Vi);
v=(sum(Vi)./m)';
v=v./sum(v);
maxiter=5;
options=[];
options.Display='none';
alpha=ones(m,1)./m;
beta=ones(m,1)./m;
rho=1;
for qq=0.9:-0.1:0.5
    lambda=2*((qq-1).^2*qq+qq^2*(1-qq))./m;
    BB=zeros(n,n);
    for j=1:m
        BB=BB+alpha(j).^2.*(S-Si(:,:,j)).^2;
    end
    A=lambda./(2.*BB);
    A(A>1)=1;
    
    for ii=1:maxiter
        XLX=X*L*X';
        VXLXV=bsxfun(@times,XLX,v');
        VXLXV=bsxfun(@times,VXLXV,v);
        VXLXV=(VXLXV+VXLXV')./2;
        [W,~]=eig1(VXLXV,c,0);

        B=W*W';
        H=2.*XLX.*B+gamma2.* sum(beta.^2).*eye(d);
        H=(H+H')./2;
        tmp=bsxfun(@times,Vi,beta.^2);
        f=-sum(tmp).*gamma2;
        
        v=quadprog(H,f,[],[],ones(1,d),1,zeros(d,1),ones(d,1),v,options);
        
        
        tmp1=zeros(n,n);
        for j=1:m
            tmp1=tmp1+alpha(j).^2.*Si(:,:,j);
        end
        tmp2=L2_distance_1(F',F');
        XV=bsxfun(@times,X,v);
        WXV=W'*XV;
        tmp3=L2_distance_1(WXV,WXV);
        S=(tmp1-(rho./gamma1.*tmp2+1./gamma1.*tmp3)./(2.*A.*A))./sum(alpha.^2);
        S(S>1)=1;
        S(S<0)=0;
        
        S = (S+S')/2;
        D = diag(sum(S));
        L = D-S;
        F_old = F;
        [F, ~, ev]=eig1(L, c, 0);
        evs(:,ii+1) = ev;
    
        tmp4=zeros(m,1);
        for j=1:m
            tmp4(j)=sum(sum((A.*(S-Si(:,:,j))).^2));
        end
        alpha=1./max(tmp4,eps);
        alpha=alpha./sum(alpha);
        
        V=repmat(v',m,1);
        beta=sum((V-Vi).^2,2);
        beta=1./max(eps,beta);
        beta=beta./sum(beta);
        
        fn1 = sum(ev(1:c));
        fn2 = sum(ev(1:c+1));
        if fn1 > 0.000000001
            rho = 2*rho;
        elseif fn2 < 0.00000000001
            rho = rho/2;  F = F_old;
        elseif ii>1
            break;
        end
    end
end
[~,idx]=sort(v,'descend');
    
    

end

