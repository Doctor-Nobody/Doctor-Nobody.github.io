function [ Y,Vi,result_single ] = generate_base( X,y,c,m)
%GENERATE_BASE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
 X = NormalizeFea(full(X),1);
 [n,d]=size(X);
 idx=randperm(n);
 batch=floor(n/m);
 start=1;
%  opt1.NeighborMode='KNN';
%  opt1.WeightMode='HeatKernel';
%  opt1.k=10;
 Vi=zeros(m,d);
% ind_Lap=zeros(d,m);
 for iter=1:m
     idx1=idx(start:min(start+batch-1,n));
     XX=X(idx1,:);
%      D=EuDist2(X);
%      optt=mean(mean(D));
%      clear D;
%      
%      opt1.t=optt;
%      A1=constructW(XX,opt1);
%      Y1=LaplacianScore(XX, A1);
%      [~,ind_Lap1] = sort(Y1,'descend');
     [RANKED, WEIGHT, SUBSET] = InfFS_U( XX, [], 0.7,0 );
     Vi(iter,:)=WEIGHT;
     ind_inffs(:,iter)=RANKED';
     start=start+batch;
 end
result_single=[];
for i=1:20
    numfea=i*10;
    for iter=1:m
        X1=X(:,ind_inffs(1:numfea,iter));
        y1=litekmeans(X1, c,  'Replicates', 20);
        res=ClusteringMeasure(y,y1);
        result_single.acc(i,iter)=res(1);
        result_single.nmi(i,iter)=res(2);
        result_single.pur(i,iter)=res(3);
        Y1=zeros(n,c);
        for j=1:n
            Y1(j,y1(j))=1;
        end
        Y{i,iter}=Y1;
    end
    
end

end

