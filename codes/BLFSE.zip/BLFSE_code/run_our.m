clear
rand('state',2)
gam1=1;
gam2=1;
result_our=[];
name='bbcnewssport_737n_1000d_5c_tfidf'
load(name);
load(['./base_results_infFS/' name]);
n=length(y);
X = NormalizeFea(full(X),1);
c=length(unique(y));

for k=1:20
    Si=zeros(n,n,10);
    for ii=1:10
        YY=Y{k,ii};
        Si(:,:,ii)=YY*YY';
    end

    [ idx ] = BLFSE( X',Vi,Si,c,gam1,gam2 );
    XX=X(:,idx(1:k*10));
    y1=litekmeans(XX, c,  'Replicates', 20);
    res=ClusteringMeasure(y,y1)
    acc(k)=res(1);
    nmi(k)=res(2);
end
result_our.acc=acc;
result_our.nmi=nmi;
save(['./result_our/' name],'result_our');
       
 