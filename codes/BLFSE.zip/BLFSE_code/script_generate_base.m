clear
rand('state',0);

name='bbcnewssport_737n_1000d_5c_tfidf.mat';
load(name);
c=length(unique(y));
[Y,Vi,result_single]=generate_base( X,y,c,10 );
Vi=Vi-1;
save(['./base_results_infFS/2' name],'Y','Vi','result_single');
 