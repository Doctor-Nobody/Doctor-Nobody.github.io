
lambda=0.1; 
gamma=[0.1:0.1:0.9];
k=25;
c=5;

load('20newsgroups_5_258_3view.mat');
num=length(X);
alpha=cell(1,num);
for i =1:num     
    Xs=X{i};
    gnd=out_label{i};
    numview=length(Xs);
    Ds=cell(1,numview);
    tSet=zeros(numview,1);

    for j=1:length(Xs) 
        Xs{j}=zscore(Xs{j});
        Ds{1,j}=EuDist2(Xs{1,j}', Xs{1,j}'); 
        tSet(j)=max(median(Ds{1,j},'all'),eps);
    end


    [score_knn,score_consensus]=MODGD(tSet,Xs,k,c,lambda);
    for j1=1:length(gamma)
       score=gamma(j1)*score_knn+(1-gamma(j1))*score_consensus; 
       [~, ~, ~, auc(j1,i)] = perfcurve(gnd,score,0);
    end     
end
mean(auc,2)'








