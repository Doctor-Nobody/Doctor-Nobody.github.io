function [score_knn,score_consensus] = MODGD(tSet,Xi,k,c,lambda)
options=[];
options.NeighborMode='KNN';
options.WeightMode='HeatKernel';
options.k=k;    
options.bSelfConnected=1;

rho=1;
num_view=length(Xi);
n=size(Xi{1},2);
alpha=ones(num_view,1)./num_view;
Ei=zeros(n,n,num_view);
Gi=Ei;
score=zeros(n,1);
score_knn=zeros(n,1);
score_consensus=zeros(n,1);
maxiter=10;

for i =1:num_view
    options.t=tSet(i);
    Gi(:,:,i)=constructW(Xi{1,i}',options); 
    num=sum((Gi(:,:,i)>0),2)-1;
    tmpscore=(sum(Gi(:,:,i),2)-diag(Gi(:,:,i)))./max(num,eps);
    tmpscore(tmpscore<0)=0;
    score_knn=score_knn+tmpscore;
    dd=sum(Gi(:,:,i),2);
    dd=dd.^(-1/2);
    Gi(:,:,i)=diag(dd)*Gi(:,:,i)*diag(dd);  
    Gi(:,:,i)=Gi(:,:,i).*(Gi(:,:,i)>eps);
end

score_knn=(score_knn-min(score_knn))./(max(score_knn)-min(score_knn));
W=score_knn*score_knn';
W1=(W>0);
W=max(W,eps);
for i=1:num_view
   Gi(:,:,i)=Gi(:,:,i).*W1;
end
G=sum(Gi,3)./num_view;
G_inal=G;

for i=1:num_view
   Ei(:,:,i)=0.5*(G-Gi(:,:,i));
end

D = diag(sum(G));
L = D - G;
[F, ~, evs]=eig1(L, c, 0);

for iter=1:maxiter
    for i =1:num_view
        Z=2*W;
        Ki=Z.*(Gi(:,:,i)-G);
        di=0.5./max(sqrt(sum(Ei(:,:,i).^2,2)),eps);
        DD=di*di';
        tmp1=di'.*Ki;
        tmp2=di+di';
        tmp3=lambda*DD+tmp2.*Z;
        Ei(:,:,i)=tmp1./max(tmp3,eps);
    end
    
    B=zeros(n,n);
    for i =1:num_view
        B=B+(Gi(:,:,i)-Ei(:,:,i)-Ei(:,:,i)')*alpha(i)*alpha(i);
    end
    distf = L2_distance_1(F',F');
    distf=distf-diag(diag(distf));
    B=B-rho.*distf./(2.*W);
    G=B./sum(alpha.^2);
    G(G<0)=0;
    G(G>1)=1;
    G=G.*W1;  

    for i =1:num_view
        l21_norm=sum(sqrt(sum(Ei(:,:,i).^2,2)));
        Ai(i)=(sum(sum(W.*(G-Gi(:,:,i)+Ei(:,:,i)+Ei(:,:,i)').^2))+lambda*l21_norm)^(-1);
    end
    alpha=Ai./sum(Ai);
    
    G = (G+G')/2;
    D = diag(sum(G));
    L = D-G;
    F_old = F;
    [F, ~, ev]=eig1(L, c, 0);
    evs(:,iter+1) = ev;

    fn1 = sum(ev(1:c));
    fn2 = sum(ev(1:c+1));
    if fn1 > 0.000000001
        rho = 2*rho;
    elseif fn2 < 0.00000000001
        rho = rho/2;  F = F_old;
    elseif iter>1
        break;
    end

end

for i=1:num_view
    tmpscore1=sum(Ei(:,:,i).^2,2);
    tmpscore2=sum((0.5*(G_inal-Gi(:,:,i))).^2,2);
    score_consensus=score_consensus+tmpscore1;
end

score_consensus=(max(score_consensus)-score_consensus)./(max(score_consensus)-min(score_consensus));
end



