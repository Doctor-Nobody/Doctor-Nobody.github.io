function [ labeled ] = selectPairs( W,S,batchsize,n )
%SELECTPAIRS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    [~,idx_tolabel]=sort(W(:),'ascend');
    threshold=W(idx_tolabel(batchsize));
    idx_tolabel1=find(W<=threshold+eps);
    max_idx=length(idx_tolabel1);
     if threshold==W(idx_tolabel(1))
        [i_cand,j_cand]=ind2sub([n,n],idx_tolabel1);
        score=zeros(1,max_idx);
        for sel=1:max_idx
            score(sel)=sum(S(i_cand(sel),:))*sum(S(j_cand(sel),:));
        end
        [~,idx_tolabel2]=sort(score,'descend');
        labeled=idx_tolabel1(idx_tolabel2(1:batchsize));
     else
        labeled=idx_tolabel(1:batchsize);
     end
end

