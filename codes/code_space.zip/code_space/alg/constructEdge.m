function [ E,mustlink,cannotlink ] = constructEdge( mustlink,cannotlink )
%CONSTRUCTEDGE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    len_must=length(mustlink);
    E=zeros(len_must,len_must);
    [num_cannot,~]=size(cannotlink);
    remove=[];
    for i=1:num_cannot
        ii=cannotlink(i,1);
        jj=cannotlink(i,2);
        ii_idx=0;
        jj_idx=0;
        for j=1:len_must
            if ~isempty(intersect(ii,mustlink{j}))
                ii_idx=j;
            end
            if ~isempty(intersect(jj,mustlink{j}))
                jj_idx=j;
            end
            if ii_idx>0 && jj_idx>0
                if E(ii_idx,jj_idx)==1
                    remove=[remove, i];
                else
                    E(ii_idx,jj_idx)=1;
                    E(jj_idx,ii_idx)=1;
                end
                break;
            end
        end
        if ii_idx==0 && jj_idx>0
            mustlink{len_must+1}=[ii];
            E=[E,zeros(len_must,1);zeros(1,len_must),0];
            E(len_must+1,jj_idx)=1;
            E(jj_idx,len_must+1)=1;
            len_must=len_must+1;
        end
        if ii_idx>0 && jj_idx==0
            mustlink{len_must+1}=[jj];
            E=[E,zeros(len_must,1);zeros(1,len_must),0];
            E(len_must+1,ii_idx)=1;
            E(ii_idx,len_must+1)=1;
            len_must=len_must+1;
        end
        if ii_idx==0 && jj_idx==0
            mustlink{len_must+1}=[ii];
            mustlink{len_must+2}=[jj];
            E=[E,zeros(len_must,2);zeros(2,len_must),[0,1;1,0]];
            len_must=len_must+2;
        end
           
    end
    cannotlink(remove,:)=[];

end

