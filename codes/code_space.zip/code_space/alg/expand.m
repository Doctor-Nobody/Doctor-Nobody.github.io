function [ V,E,cannotlink ] = expand( cons,V_old,cannot )
%CG �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[num_cons,~]=size(cons);
label=cons(:,3);
idx=find(label==1);
idx_cannot=setdiff(1:num_cons,idx);

num_must=length(idx);
for i=1:num_must
    mustlink{i}=cons(idx(i),1:2);
end
cannotlink=cons(idx_cannot,1:2);

if ~exist('V_old','var')
    if isempty(idx)
        mustlink=[];
    else
        mustlink=transclos(mustlink);
    end
        [E,V,cannotlink]=constructEdge(mustlink,cannotlink);
else
    cannotlink=[cannot;cannotlink];
    if isempty(idx)
        mustlink=[];
    else
        mustlink=[V_old,mustlink];
    end
    mustlink=transclos(mustlink);
    [E,V,cannotlink]=constructEdge(mustlink,cannotlink); 
end
    

        
                
    


end

