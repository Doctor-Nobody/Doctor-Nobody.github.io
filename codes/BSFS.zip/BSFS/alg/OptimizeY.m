function [ Y ] = OptimizeY( Y,XW,S,Phi,p,mu1 )
%OPTIMIZEY �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[n,c]=size(XW);
maxiter=5;
c0=sum(sum((Y-XW).^2));
tempYS=Y'*S;
c3=sum(sum(tempYS.*Y'));
tmp=sum(Y);
for i=1:maxiter
    YYY=Y;
    for j=1:n
        idx_last=find(Y(j,:)==1);
        c1=c0-sum((Y(j,:)-XW(j,:)).^2);
        c2=sum((eye(c)-repmat(XW(j,:),c,1)).^2,2);

        
        c4=2.*(tempYS(:,j)-tempYS(idx_last,j));

        c5=2.*S(j,j);

        tmp(idx_last)=tmp(idx_last)-1;
        tmp2=repmat(p,c,1)-(repmat(tmp,c,1)+eye(c))./n;

        c6=sum(repmat(Phi,c,1).*tmp2,2);
        c7=sum(tmp2.*tmp2,2).*mu1./2;
        obj=(c1+c2)./(c3+c4+c5)+c6+c7;
        [~,minobj]=min(obj);
        if minobj~=idx_last
            Y(j,idx_last)=0;
            Y(j,minobj)=1;
            c0=c1+sum((Y(j,:)-XW(j,:)).^2);
            tempYS([minobj,idx_last],:)=tempYS([minobj,idx_last],:)+[ones(1,n);-1.*ones(1,n)].*[S(j,:);S(j,:)];
            c3=sum(sum(tempYS.*Y'));
        end

         
        tmp(minobj)=tmp(minobj)+1;
    end
    if sum(sum(abs(YYY-Y)))==0
        break;
    end
end
        
        
end


