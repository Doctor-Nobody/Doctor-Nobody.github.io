function [ idx_sel,Y,obj1 ] = BSFS( X,c,lambda,k )
%OPTIMIZE �˴���ʾ�йش˺�����ժҪ
%   X: n * d
[n,d]=size(X);
D=EuDist2(X);
optt=mean(D(:));
options.NeighborMode='KNN';
options.WeightMode='HeatKernel';
options.k=10;
options.t=optt;
S = constructW(X,options);
dd=sqrt(1./max(sum(S,2),eps));
S=sparse(diag(dd)*S*diag(dd));
clear L vec;

Y=zeros(n,c);
for i=1:n
    idxr=randi(c);
    Y(i,idxr)=1;
end
Y=sparse(Y);
maxiter=50;
mu1=1;
mu2=1;
rho1=1.1;
rho2=1.1;
Gamma=zeros(d,c);
V=zeros(d,c);
[~,XS,XV]=svd(X,'econ');
XS=diag(XS);
XS=XS.*XS;
Phi=zeros(1,c);
obj1=[];
p=ones(1,c)./c;
tmp1=Y'*S;
alpha=1./sum(sum(tmp1.*Y'));
clear tmp1;
W=OptimizeW(X,XS,XV,Y,Gamma,V,alpha,mu2);
for i=1:maxiter
    tmp1=Y'*S;
    alpha=1./sum(sum(tmp1.*Y'));
    clear tmp1;
    W=OptimizeW(X,XS,XV,Y,Gamma,V,alpha,mu2);
    V=OptimizeV(W,Gamma,mu2,k);
    p=OptimizeP(Y,lambda,Phi,mu1);
    XW=X*W;
    Y=OptimizeY(Y,XW,S,Phi,p,mu1);
    
    
    cc=sum(Y)./n;
    Phi=Phi+mu1.*(p-cc);
    mu1=mu1*rho1;
    Gamma=Gamma+mu2.*(W-V);
    mu2=mu2*rho2;
end
idx_sel=find(sum(V.^2,2));

