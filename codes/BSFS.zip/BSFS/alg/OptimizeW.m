function [ W ] = OptimizeW( X,S,XV,Y,Gamma,V,alpha,mu )
%OPTIMIZEW �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[n,d]=size(X);
if n>d
    S=1./max(S+mu./(2*alpha),eps);
    XY=X'*Y;    
    GammaV=(Gamma-mu.*V)./(2*alpha);
    VS=bsxfun(@times,XV,S');
    W=VS*(XV'*XY)-VS*(XV'*GammaV);
else
    a=mu./(2*alpha);
    XY=X'*Y;
    GammaV=(Gamma-mu.*V)./(2*alpha);
    tmp1=(XY-GammaV)./a;
    tmp2=1./(1./max(S,eps)+1./a);
    VS=bsxfun(@times,XV,tmp2');
    tmp3=(VS*(XV'*XY)-VS*(XV'*GammaV))./(a*a);
    W=tmp1-tmp3;
end

end

