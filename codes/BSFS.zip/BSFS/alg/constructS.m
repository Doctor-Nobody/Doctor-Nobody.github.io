function [ GG,t ] = constructS( X,k )
%CONSTRUCTS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
tic
[n,d]=size(X);
X1=X(1:30000,:);
X2=X(30001:60000,:);
D11=EuDist2(X1,X1);
opt1=mean(D11(:));
D12=EuDist2(X1,X2);
opt2=mean(D12(:));
D22=EuDist2(X2,X2);
opt3=mean(D22(:));
optt=(opt1+opt2*2+opt3)./4;
clear X X1 X2;

D11=exp(-D11.^2./(2*optt.^2));
D12=exp(-D12.^2./(2*optt.^2));
D22=exp(-D22.^2./(2*optt.^2));

nSmpNow=30000;
smpIdx = 1:nSmpNow;
G = zeros(2*nSmpNow*k,3);
%nSmpNow = length(smpIdx);
dump = zeros(nSmpNow,k);
D11=[D11,D12];
for j = 1:k
    [dump(:,j),idx(:,j)] = max(D11,[],2);
    temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
    D11(temp) = -1e100;
end
clear D11;
G(1:nSmpNow*k,1) = repmat(smpIdx',[k,1]);
G(1:nSmpNow*k,2) = idx(:);
G(1:nSmpNow*k,3) = dump(:);

D12=[D12',D22];
clear D22;
for j = 1:k
    [dump(:,j),idx(:,j)] = max(D12,[],2);
    temp = (idx(:,j)-1)*nSmpNow+[1:nSmpNow]';
    D12(temp) = -1e100;
end
clear D12;
G(nSmpNow*k+1:nSmpNow*k*2,1) = repmat(30000+smpIdx',[k,1]);
G(nSmpNow*k+1:nSmpNow*k*2,2) = idx(:);
G(nSmpNow*k+1:nSmpNow*k*2,3) = dump(:);

GG = sparse(G(:,1),G(:,2),G(:,3),2*nSmpNow,2*nSmpNow);
GG=max(GG,GG');
t=toc;

end

