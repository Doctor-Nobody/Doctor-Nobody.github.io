clear
rand('state',0);


name='CBCL1000.mat';
load('CBCL1000.mat');
c=length(unique(y));
[n,d]=size(X);
X=NormalizeFea(full(X),1);
lambda_vec=-5:1:5;
for para=1:length(lambda_vec)
    lambda=10^(lambda_vec(para));
    for k=10:10:100
        [para k]
        tic
            idx_sel = BSFS( X,c,lambda,k );
        toc
        XX=X;
        XX(:,setdiff(1:d,idx_sel))=[];
        for l=1:10
            label1=litekmeans(XX,c);
            res2=ClusteringMeasure(y,label1);
            accv(l)=res2(1);
            nmiv(l)=res2(2);
            FF=zeros(n,c);
            for ii=1:n
                FF(ii,label1(ii))=1;
            end
            ys=sum(FF);
            entropy = BalanceEvl(c, ys);
            entv(l)=entropy;
         end
         acc2(k/10)=mean(accv);
         nmi2(k/10)=mean(nmiv);
         ent2(k/10)=mean(entv);
    end
    result_our{para}.acc=acc2;
    result_our{para}.nmi=nmi2;
    result_our{para}.ent=ent2;
    save(['./result_our/result_' name],'result_our');
end

    