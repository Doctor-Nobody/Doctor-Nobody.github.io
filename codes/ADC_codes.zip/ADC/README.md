keras == 2.0.9
tensorflow-gpu == 1.14
h5py == 2.10