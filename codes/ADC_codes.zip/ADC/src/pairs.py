import random
import math
import numpy as np


def create_pairs_active(x, centroid, hard_class, num_classes, y, ratio):
    pairs = []
    labels = []
    for d in range(num_classes):
        n = math.ceil(len(hard_class[d]) * ratio)
        for i in range(n):
            z1, z2 = centroid[d], hard_class[d][i]
            a = np.array(y[z1] == y[z2]).astype(int)
            pairs += [[x[z1], x[z2]]]
            labels += [a]
    return np.array(pairs), np.array(labels), np.array(pairs).shape[0]


def create_pairs_random(x, budgets, y):
    pairs = []
    labels = []
    while np.array(pairs).shape[0] < budgets:
        a = random.randrange(1, budgets)
        b = random.randrange(1, budgets)
        pairs += [[x[a], x[b]]]
        q = np.array(y[a] == y[b]).astype(int)
        labels += [q]
    return np.array(pairs), np.array(labels), np.array(pairs).shape[0]
