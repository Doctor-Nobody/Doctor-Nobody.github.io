from sklearn import metrics
import logging
from keras.models import Model, load_model
from keras.layers import Dense, Activation, Flatten, Input, Lambda, Convolution2D, MaxPooling2D, AveragePooling2D, \
    BatchNormalization
from keras.engine.topology import Layer, InputSpec
import numpy as np
from keras import backend as K


class ClusteringLayer(Layer):
    def __init__(self, n_clusters, weights=None, alpha=1.0, **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(ClusteringLayer, self).__init__(**kwargs)
        self.n_clusters = n_clusters
        self.alpha = alpha
        self.initial_weights = weights
        self.input_spec = InputSpec(ndim=2)

    def build(self, input_shape):
        assert len(input_shape) == 2
        input_dim = input_shape[1]
        self.input_spec = InputSpec(dtype=K.floatx(), shape=(None, input_dim))
        self.clusters = self.add_weight((self.n_clusters, input_dim), initializer='glorot_uniform', name='clusters')
        if self.initial_weights is not None:
            self.set_weights(self.initial_weights)
            del self.initial_weights
        self.built = True

    def call(self, inputs, **kwargs):
        """ student t-distribution, as same as used in t-SNE algorithm.
                 q_ij = 1/(1+dist(x_i, u_j)^2), then normalize it.
        Arguments:
            inputs: the variable containing data, shape=(n_samples, n_features)
        Return:
            q: student's t-distribution, or soft labels for each sample. shape=(n_samples, n_clusters)
        """
        q = 1.0 / (1.0 + (K.sum(K.square(K.expand_dims(inputs, axis=1) - self.clusters), axis=2) / self.alpha))
        q **= (self.alpha + 1.0) / 2.0
        q = K.transpose(K.transpose(q) / K.sum(q, axis=1))
        return q

    def compute_output_shape(self, input_shape):
        assert input_shape and len(input_shape) == 2
        return input_shape[0], self.n_clusters

    def get_config(self):
        config = {'n_clusters': self.n_clusters}
        base_config = super(ClusteringLayer, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


def cov(img_channels, img_rows, img_cols, nb_classes):
    inp_ = Input(shape=(img_rows, img_cols, img_channels))
    x = Convolution2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(inp_)
    x = BatchNormalization(axis=1)(x)
    x = Convolution2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = Convolution2D(filters=64, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding="SAME")(x)

    x = Convolution2D(filters=128, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = Convolution2D(filters=128, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = Convolution2D(filters=128, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding="SAME")(x)

    x = Convolution2D(filters=256, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = Convolution2D(filters=256, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = Convolution2D(filters=256, kernel_size=(3, 3), strides=(1, 1), padding="SAME", activation="relu")(x)
    x = BatchNormalization(axis=1)(x)
    x = MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding="SAME")(x)

    x = Convolution2D(nb_classes, 1, 1, init='he_normal')(x)
    x = BatchNormalization(axis=1)(x)
    x = Activation('relu')(x)
    x = AveragePooling2D(pool_size=(6, 6), strides=(2, 2), padding="SAME")(x)
    x0 = Flatten()(x)
    x2 = Dense(nb_classes, init='he_normal')(x0)

    x1 = Activation('relu')(x2)
    x1 = Dense(nb_classes, init='he_normal')(x1)
    cluster_l1 = Model(input=[inp_], output=[x2])
    clustering_layer = ClusteringLayer(nb_classes, name='clustering')(x2)
    model_dec = Model(inputs=[inp_], outputs=clustering_layer)

    return cluster_l1, model_dec


def acc(y_true, y_pred):
    """ Calculate clustering accuracy

    Require scikit-learn installed

    :param y_true: true labels
    :param y_pred: predicted labels
    :return: accuracy, in [0,1]
    """
    y_true = y_true.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    from sklearn.utils.linear_assignment_ import linear_assignment
    ind = linear_assignment(w.max() - w)
    return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size


def cluster_performance(y_pred, y_train, label='kmean'):
    """ calculate performance of clustering


    :param y_pred: Predication vector
    :param y_train: Ground truth vector
    :param label: Method name
    :return: NMI, ACC, ARI
    """
    k_means_nmi = metrics.normalized_mutual_info_score(y_train, y_pred)
    k_means_ari = metrics.adjusted_rand_score(y_train, y_pred)
    k_means_acc = acc(y_train, y_pred)
    # print('{} NMI is {}'.format(label, k_means_nmi))
    # print('{} ARI is {}'.format(label, k_means_ari))
    # print('{} Acc is {}'.format(label, k_means_acc))
    logging.info("NMI - {:0.2f},ARI - {:0.2f},ACC - {:0.2f}".format(k_means_nmi, k_means_ari, k_means_acc))
    return k_means_nmi, k_means_acc, k_means_ari
