# from __future__ import print_function
from keras.datasets import mnist, fashion_mnist
import numpy as np

def load_mnist():
    (x_train, y_train), (x_test, y_test) = mnist.load_data()
    x_train = x_train.astype('float32')
    x_test = x_test.astype('float32')
    x = np.concatenate((x_train, x_test))
    y = np.concatenate((y_train, y_test))
    x = x.reshape([x.shape[0], -1]) / 255.0
    print('MNIST:', x.shape)
    return x, y


def load_fashion_mnist():
    from keras.datasets import fashion_mnist  # this requires keras>=2.0.9
    (x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()
    x = np.concatenate((x_train, x_test))
    y = np.concatenate((y_train, y_test))
    x = x.reshape([x.shape[0], -1]) / 255.0
    print('Fashion MNIST:', x.shape)
    return x, y




def load_usps(data_path='./data/usps'):
    with open(data_path + '/usps_train.jf') as f:
        data = f.readlines()
    data = data[1:-1]
    data = [list(map(float, line.split())) for line in data]
    data = np.array(data)
    data_train, labels_train = data[:, 1:], data[:, 0]

    with open(data_path + '/usps_test.jf') as f:
        data = f.readlines()
    data = data[1:-1]
    data = [list(map(float, line.split())) for line in data]
    data = np.array(data)
    data_test, labels_test = data[:, 1:], data[:, 0]

    x = np.concatenate((data_train, data_test)).astype('float64') / 2.
    y = np.concatenate((labels_train, labels_test))
    # x = x.reshape([-1, 16 * 16])
    print('USPS samples', x.shape)
    return x, y


def load_data_cnn(datasets):
    if datasets == 'mnist':
        (x_train, y_train), (x_test, y_test) = mnist.load_data()
        x = np.concatenate((x_train, x_test))
        y = np.concatenate((y_train, y_test))
        y = y.reshape(y.shape[0])
        x = x.reshape(x.shape[0], x.shape[1], x.shape[2], 1)
    elif datasets == 'fashion':
        (x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()
        x = np.concatenate((x_train, x_test))
        y = np.concatenate((y_train, y_test))
        y = y.reshape(y.shape[0])
        x = x.reshape(x.shape[0], x.shape[1], x.shape[2], 1)
    elif datasets == 'usps':
        with open('./data/usps' + '/usps_train.jf') as f:
            data = f.readlines()
        data = data[1:-1]
        data = [list(map(float, line.split())) for line in data]
        data = np.array(data)
        data_train, labels_train = data[:, 1:], data[:, 0]

        with open('./data/usps' + '/usps_test.jf') as f:
            data = f.readlines()
        data = data[1:-1]
        data = [list(map(float, line.split())) for line in data]
        data = np.array(data)
        data_test, labels_test = data[:, 1:], data[:, 0]

        x = np.concatenate((data_train, data_test)).astype('float64') / 2.
        y = np.concatenate((labels_train, labels_test))
        x = x.reshape(x.shape[0], 16, 16, 1)
        print('USPS samples', x.shape)
    return x, y
