from time import time

from src.utils import cov
import math
import numpy as np
from keras.optimizers import RMSprop, SGD
from sklearn.cluster import KMeans
from src.datasets import load_data_cnn
from src.loss import euclidean_distance, contrastive_loss, eucl_dist_output_shape, accuracy
from src.pairs import create_pairs_active, create_pairs_random
from src.utils import cluster_performance
from keras.models import Model
from keras.layers import Dense, Activation, Flatten, Input, Lambda, Convolution2D, MaxPooling2D, AveragePooling2D

os.environ["CUDA_VISIBLE_DEVICES"] = '0'

class ActiveDeepClustering():
    def __init__(self, datasets, iteration, ratio):
        self.datasets = datasets
        self.iteration = iteration
        self.ratio = ratio
        self.x, self.y = load_data_cnn(datasets)
        self.num_classes = len(np.unique(self.y))
        self.model, self.cluster, self.cnn = self.net()

    def net(self):
        channels, rows, cols = self.x.shape[3], self.x.shape[1], self.x.shape[2]
        cnn_module, model_cluster = cov(channels, rows, cols, self.num_classes)
        model_cluster.compile(loss='kld', optimizer=SGD(lr=0.001, momentum=0.9))
        base_network = cnn_module
        input_a = Input(shape=(rows, cols, channels))
        input_b = Input(shape=(rows, cols, channels))
        processed_a = base_network(input_a)
        processed_b = base_network(input_b)
        distance = Lambda(euclidean_distance,
                          output_shape=eucl_dist_output_shape)([processed_a, processed_b])

        model = Model([input_a, input_b], distance)
        rms = RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)
        model.compile(loss=contrastive_loss, optimizer=rms, metrics=[accuracy])
        model.summary()
        return model, model_cluster, base_network

    def clustering(self, x, y=None, tol=1e-3, update_interval=140, maxiter=2e4, batchsize=32):
        # initialize cluster centers using k-means
        kmeans = KMeans(n_clusters=10, n_init=100)
        y_pred = kmeans.fit_predict(self.cnn.predict(x))
        y_pred_last = y_pred
        self.cluster.get_layer(name='clustering').set_weights([kmeans.cluster_centers_])

        index = 0
        for ite in range(int(maxiter)):
            if ite % update_interval == 0:
                q = self.cluster.predict(x, verbose=0)  # n_sample * n_classes
                weight = q ** 2 / q.sum(0)
                p = (weight.T / weight.sum(1)).T  # update the auxiliary target distribution p

                # evaluate the clustering performance
                y_pred = q.argmax(1)
                delta_label = np.sum(y_pred != y_pred_last).astype(np.float32) / y_pred.shape[0]
                if delta_label > 0.01:
                    return y_pred_last
                else:
                    y_pred_last = y_pred
                # check stop criterion
                if ite > 0:
                    if delta_label < tol or delta_label > 0.01:
                        break

            # train on batch
            if (index + 1) * batchsize > x.shape[0]:
                loss = self.cluster.train_on_batch(x=x[index * batchsize::],
                                                   y=p[index * batchsize::])
                index = 0

            else:
                loss = self.cluster.train_on_batch(x=x[index * batchsize:(index + 1) * batchsize],
                                                   y=p[index * batchsize:(index + 1) * batchsize])

                index += 1
            ite += 1
        return y_pred

    def train(self):
        perform = np.zeros((self.iteration, 3))
        pairs_all_list = []
        labels_all_list = []
        n_its = math.ceil(self.x.shape[0] / self.iteration)
        index_all = np.arange(self.x.shape[0])
        for i in range(self.iteration):
            index = index_all[i * n_its:(i + 1) * n_its]
            x_its = self.x[index]
            y_its = self.y[index]
            budgets = int(x_its.shape[0] * self.ratio)
            t1 = time()
            if i == 0:
                pairs, labels, size = create_pairs_random(self.x, budgets, self.y)
            else:
                q = self.cluster.predict(x_its, verbose=0)
                y_dec = q.argmax(1)
                predict_class = len(np.unique(y_dec))
                confidence = np.max(q, 1)
                centroid = []
                hard_class = []
                for j in range(predict_class):
                    e = np.where(y_dec == j)[0]
                    losses1 = confidence[e]
                    c1 = np.argsort(-losses1)[0]
                    h1 = np.argsort(losses1)
                    c1_index = e[c1]
                    h1_index = e[h1]
                    centroid += [c1_index]
                    hard_class += [h1_index]
                pairs, labels, size = create_pairs_active(x_its, centroid, hard_class, predict_class, y_its,
                                                          self.ratio)
            pairs_all_list += pairs.tolist()
            labels_all_list += labels.tolist()
            pairs_all = np.array(pairs_all_list)
            labels_all = np.array(labels_all_list)
            self.model.fit([pairs_all[:, 0], pairs_all[:, 1]], labels_all,
                           batch_size=64,
                           epochs=100, verbose=0)

            y_pred = self.clustering(self.x, y=None, tol=0.0001, maxiter=2e3,
                                     update_interval=140, batchsize=64)
            perform[i, :] = cluster_performance(y_pred, self.y)
            print('Number of constraints', labels_all.size)
            print('NMI ACC ARI : ', cluster_performance(y_pred, self.y))
        print(perform)

    def train_with_selected(self):
        perform = np.zeros((self.iteration, 3))
        pairs = np.load(self.datasets + "_selected_pair.npy")
        label = np.load(self.datasets + "_selected_label.npy")
        n_its = int(pairs.shape[0] / self.iteration)
        for i in range(self.iteration):
            num = n_its * (i + 1)
            pairs_all = pairs[0:num]
            labels_all = label[0:num]
            self.model.fit([pairs_all[:, 0], pairs_all[:, 1]], labels_all,
                           batch_size=64,
                           epochs=100, verbose=0)
            y_pred = self.clustering(self.x, y=None, tol=0.001, maxiter=2e3,
                                     update_interval=140, batchsize=64)
            perform[i, :] = cluster_performance(y_pred, self.y)
            print('Number of constraints', labels_all.size)
            print('NMI ACC ARI : ', cluster_performance(y_pred, self.y))
        print(perform)


if __name__ == '__main__':
    ADC = ActiveDeepClustering('usps', 5, 0.2)
    ADC.train()
