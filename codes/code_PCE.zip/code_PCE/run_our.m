clear

m1=10;
m2=10;
nn2=7;
gamma=1;
for j=1:nn2
    j
    load(['./pixraw10P/' num2str(j)]);
    for iter=1:m1
        Yi={};
        for k=1:m2
            idxi=(iter-1)*10+k;
            Hoi{k}=Hi{idxi};
            idx_input{k}=idx_u{idxi};
        end
            
        ypred = PCE_orth2( Hoi,idx_input,gamma );
            
        res=ClusteringMeasure(y,ypred);
        our_acc(j,iter)=res(1);
        our_nmi(j,iter)=res(2);
            
    end
end

x=1:7;
figure;
plot(x,mean(our_acc,2));
figure;
plot(x,mean(our_nmi,2));
