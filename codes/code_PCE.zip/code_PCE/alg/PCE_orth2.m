function [ ypred,obj1 ] = PCE_orth2( Hoi,idx_u ,gamma)
%PCE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
opts.record = 0;
opts.mxitr  = 200;
opts.xtol = 1e-5;
opts.gtol = 1e-5;
opts.ftol = 1e-8;
opts.tau = 1e-3;


m=length(Hoi);
[n,c]=size(Hoi{1});
alpha=1./m.*ones(m,1);
KC=zeros(n,n);
for i=1:m
    KC=KC+Hoi{i}*Hoi{i}';
end
KC=KC./m;
H= mykernelkmeans(KC,c);

[CC,RR]=mydiscretisation(H,1);


opt=[];
opt.Display='none';
for i=1:m
    R{i}=eye(c);
    Hu{i}=zeros(length(idx_u{i}),c);
end
for i=1:m
    G=-2./m*H'*Hoi{i};
    for j=1:m
        if j==i
            continue;
        else
            G=G+2./(m*m).*R{j}'*(Hoi{j}'*Hoi{i});
        end
    end
    [U,~,V]=svd(-G');
    R{i}=U*V';
end

maxiter=20;

v=zeros(n,1);

opt=[];
opt.Display='none';

B=zeros(n,c);
for j=1:m
    B=B+alpha(j).*Hoi{j}*R{j};
end
A=H-B;
 a=2.*sum(A.^2,2);
aa=sort(a,'ascend');
lambda=aa(floor(n/10));
if lambda==0
    lambda=0.001;
end

for i=1:maxiter
    %update V
    B=zeros(n,c);
    for j=1:m
        B=B+alpha(j).*Hoi{j}*R{j};
    end
    A=H-B;
    a=sum(A.^2,2);
    v=lambda./(2.*a);
    v(v>1)=1;
    

    % update H
    CR=CC*RR';
    [H]= OptStiefelGBB(H, @solveH2, opts, v,B,gamma,CR);

    
    %update Hu
    for j=1:m
        Vu=v(idx_u{j});
        Vu=Vu.^2.*alpha(j);
        Fu=zeros(n,c);
        for k=1:m
            if k==j
                continue;
            else
                HH=Hoi{k};
                HH(idx_u{k},:)=Hu{k};
                Fu=Fu+alpha(k).*HH*R{k};
            end
        end
        RH=R{j}*(-2.*H(idx_u{j},:)+2.*Fu(idx_u{j},:))';
        RHV=bsxfun(@times,RH,Vu');
        [~,idx_tmp]=min(RHV,[],1);
        HHu=zeros(size(Hu{j}));
        idx_nz=sub2ind(size(Hu{j}),1:length(idx_u{j}),idx_tmp);
        HHu(idx_nz)=1;
        Hu{j}=HHu;
    end
    
    for j=1:m
        HH=Hoi{j};
        HH(idx_u{j},:)=Hu{j};
        Hoi{j}=HH;
    end
    

    %update alpha
    for j=1:m
        C{j}=Hoi{j}*R{j};
        VC{j}=bsxfun(@times,C{j},v.^2);
    end
    Q=-inf.*ones(m,m);
    for j=1:m
        for k=j:m
            Q(j,k)=sum(sum(C{j}.*VC{k}));
        end
    end
    Q=max(Q,Q');
    f=zeros(m,1);
    for j=1:m
        f(j)=-sum(sum(H.*VC{j}));
    end
    alpha=quadprog(Q,f,[],[],ones(1,m),1,zeros(m,1),ones(m,1),alpha,opt);
    
    %update R
    E=bsxfun(@times,H,v);
    for j=1:m
        Fi{j}=alpha(j).*bsxfun(@times,Hoi{j},v);
    end
    for j=1:m
        G=-2.*E'*Fi{j};
        for k=1:m
            if k==j
                continue;
            else
                G=G+2.*R{k}'*(Fi{k}'*Fi{j});
            end
        end
        [U,~,V]=svd(-G');
        R{j}=U*V';
        
    end
    
    [CC,RR]=mydiscretisation(H,0);
    if i<10
        lambda=lambda*1.1;
    end
end
[~,ypred]=max(CC,[],2);

