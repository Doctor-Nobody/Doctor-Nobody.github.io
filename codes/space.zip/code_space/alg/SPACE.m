function [ S,constraints,res_acc,res_nmi ] = SPACE( Ai,c,gamma,y,batchsize,T,delta )
%OPTIMIZE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[n,~,m]=size(Ai);
A=sum(Ai,3)./m;
A = (A+A')/2;
D = diag(sum(A));
L = D - A;
[F, ~, evs]=eig1(L, c, 0);

S=A;


p=ones(1,m)./m;
phi=zeros(1,m);
maxiter=5;
lambda=1;
gamma=sqrt(gamma);
cons=[];
Y_cannot=[];
cannot_index=[];
idx_labeled=[];
qq=0.9;
constraints=[];
res_acc=zeros(1,T);
res_nmi=zeros(1,T);
dia=1:n+1:n*n;
for iter=1:T   
    rho=2*((qq-1).^2*qq+qq^2*(1-qq))/m;
    SS=zeros(n,n);
    for j=1:m
        SS=SS+(S-Ai(:,:,j)).^2.*p(j)^2;
    end
    SS=SS.*2;
    W=rho./SS;
    W(W>1)=1;
    WW=W;
    WW(idx_labeled)=2;
    WW=tril(WW)+triu(ones(n,n).*2);
    SSS=zeros(n,n);
    labeled=selectPairs(WW,S,batchsize,n);
    clear WW;
    W(idx_labeled)=1;
    constraints=[constraints;labeled];
    [i_label,j_label]=ind2sub([n,n],labeled);
    for kk=1:batchsize
        if y(i_label(kk))==y(j_label(kk))
            cons=[cons;[i_label(kk),j_label(kk),1]];
        else
            cons=[cons;[i_label(kk),j_label(kk),-1]];
            Y_cannot=[Y_cannot,zeros(n,1)];
            Y_cannot(i_label(kk),end)=1;
            Y_cannot(j_label(kk),end)=-1;
            cannot_index=[cannot_index;[i_label(kk),j_label(kk)]];
        end
    end
    [V,E,~]=expand(cons);
    for jj=1:length(V)
        SSS(V{jj},V{jj})=1;
    end
    [i_E,j_E]=find(E>0);
    for jj=1:length(i_E)
        SSS(V{i_E(jj)},V{j_E(jj)})=-1;
    end
    idx_labeled=find(SSS(:)~=0);
    
    idx_must=find(SSS(:)==1);
    idx_cannot=find(SSS(:)==-1);
    [~,num_can]=size(Y_cannot);
    for ii=1:maxiter
        B=zeros(n,n);
        for j=1:m
            B=B+Ai(:,:,j).*p(j)^2;
        end
        distf = L2_distance_1(F',F');
        distY=L2_distance_1(Y_cannot',Y_cannot');
        
        beta=1.*lambda;
        if isempty(distY)
            B=B-(lambda.*distf)./(2.*W.*W);
        else
            B=B-(lambda.*distf+beta.*distY)./(2.*W.*W);
        end
        S=B./sum(p.^2);
        S(S<gamma./(W.*sqrt(sum(p.^2))))=0;
        S(S>1)=1;
        S(idx_must)=1;
        S(idx_cannot)=0;
        S(dia)=1;
        
        S = (S+S')/2;
        D = diag(sum(S));
        L = D-S;
    
        F_old = F;
   
        [F, ~, ev]=eig1(L, c, 0);

        evs(:,ii+1) = ev;

        [~, ypred]=graphconncomp(sparse(S));
        for j=1:num_can
            l_idx=cannot_index(j,:);
      
            if ypred(l_idx(1))~=ypred(l_idx(2))
                yk=zeros(n,1);
                idx_1=find(ypred==ypred(l_idx(1)));
                idx_2=find(ypred==ypred(l_idx(2)));
                yk(idx_1)=1;
                yk(idx_2)=-1;
                Y_cannot(:,j)=yk;
            else
                idx_3=find(ypred==ypred(l_idx(1)));
                u_idx=setdiff(idx_3,l_idx);
                Lul=L(u_idx,l_idx);
                Luu=L(u_idx,u_idx);
                l1=Lul(:,1)-Lul(:,2);
                ykk=(Luu)\l1;
                Y_cannot(u_idx,j)=ykk;
            end
        end
    
        for j=1:m
            phi(j)=max(sum(sum(((S-Ai(:,:,j)).*W).^2)),eps);
        end
        p=(1./phi)./sum(1./phi);
    
        fn1 = sum(ev(1:c));
        fn2 = sum(ev(1:c+1));
        if fn1 > 0.000000001
            lambda = 2*lambda;
        elseif fn2 < 0.00000000001
            lambda = lambda/2;  F = F_old;
        elseif ii>1
            break;
        end
    end

    [~, ypred]=graphconncomp(sparse(S));
    ypred = ypred';
    res=ClusteringMeasure(y,ypred);
    res_acc(iter)=res(1);
    res_nmi(iter)=res(2);
    if qq>0.5
        qq=qq-delta;
    end
end



end

