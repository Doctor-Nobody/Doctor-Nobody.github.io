function [ mustlink ] = transclos( mustlink )
%TRANS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
start=1;
num_must=length(mustlink);
while start<num_must
        flag=0;
        i=start+1;
        while i<=num_must
            if ~isempty(intersect(mustlink{start},mustlink{i}))
                mustlink{start}=union(mustlink{start},mustlink{i});
                mustlink(i)=[];
                num_must=num_must-1;
                flag=1;
            else
                i=i+1;
            end
        end
        if flag==0
            start=start+1;
        end
    
end

