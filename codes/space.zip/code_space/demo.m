clear
rand('state',0);

name='AR_840n_768d_120c_zscore'
load(['./' name '.mat']);
c=length(unique(y));
batchsize=50;
m=20;
delta=0.1;
n=length(y);
result_acc=zeros(10,10);
result_nmi=result_acc;
for iter=1:10
    Ai=zeros(n,n,m);
    for j=1:m
        idxi=(iter-1)*20+j;
        YY=sparse(Yi{idxi});
        Ai(:,:,j)=full(YY*YY');
    end
    for gam=1:10
        gamma=(gam-1).*0.1;
        gamma=gamma.^2./m;
        [S,constraints,res_acc,res_nmi]  = SPACE( Ai,c,gamma,y,batchsize,10,delta );
        cons{iter,gam}=constraints;
        result_acc_details{iter,gam}=res_acc;
        result_nmi_details{iter,gam}=res_nmi;
        [clusternum, ypred]=graphconncomp(sparse(S)); 
        ypred = ypred';
        res=ClusteringMeasure(y,ypred)
        result_acc(iter,gam)=res(1);
        result_nmi(iter,gam)=res(2);
           
    end
end
save(['./result/' name],'result_acc','result_nmi');
